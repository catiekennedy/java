public class T
{
	public static void main(String[] args)
	{
		Temperature test = new Temperature();
		test.writeC();
	}
}